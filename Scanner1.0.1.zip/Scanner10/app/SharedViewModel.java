package com.example.scanner10;  // Make sure this matches your package name

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.Arrays;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData<ArrayList<String>> items = new MutableLiveData<>(new ArrayList<>(Arrays.asList("Paper Towels", "Plastic Bags", "Paper Bags", "Dryer Sheets", "Broom Handles")));
    private final MutableLiveData<ArrayList<String>> numbs = new MutableLiveData<>(new ArrayList<>(Arrays.asList("44", "67", "35", "101", "32")));

    public LiveData<ArrayList<String>> getItems() {
        return items;
    }

    public LiveData<ArrayList<String>> getNumbs() {
        return numbs;
    }

    public void setItems(ArrayList<String> newItems) {
        items.setValue(newItems);
    }

    public void setNumbs(ArrayList<String> newNumbs) {
        numbs.setValue(newNumbs);
    }

    public interface ListUpdater {
        void update(ArrayList<String> list);
    }
}
