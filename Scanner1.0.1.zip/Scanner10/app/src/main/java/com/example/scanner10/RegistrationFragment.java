package com.example.scanner10;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.core.view.ViewCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.WindowInsetsCompat;

public class RegistrationFragment extends Fragment {

    private DatabaseHelper dbHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the fragment layout
        View rootView = inflater.inflate(R.layout.activity_registration_fragment, container, false);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(getContext());

        // Get references to the EditTexts and Button
        EditText editTextEmail = rootView.findViewById(R.id.editTextEmail);
        EditText editTextPassword = rootView.findViewById(R.id.editTextPassword);
        rootView.findViewById(R.id.buttonRegister).setOnClickListener(v -> {
            // Retrieve entered username and password
            String enteredUsername = editTextEmail.getText().toString().trim();
            String enteredPassword = editTextPassword.getText().toString().trim();

            if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                Toast.makeText(getContext(), "Please enter both email and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // Attempt to insert the user into the database
            boolean isInserted = dbHelper.insertUser(enteredUsername, enteredPassword);
            if (isInserted) {
                Toast.makeText(getContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                // You might want to navigate to the login screen or auto-login the user here
            } else {
                Toast.makeText(getContext(), "Registration Failed: Username may already exist", Toast.LENGTH_SHORT).show();
            }
        });

        // Apply window insets to handle system bars (optional)
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        return rootView;
    }
}
