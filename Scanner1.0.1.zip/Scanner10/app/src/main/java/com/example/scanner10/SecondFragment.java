package com.example.scanner10;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.scanner10.databinding.FragmentSecondBinding;
import java.util.ArrayList;

public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    private DatabaseHelper dbHelper;
    private ListView itemsListView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> itemsList;

    // Set a threshold for low inventory
    private static final int LOW_INVENTORY_THRESHOLD = 10;
    // Hardcoded phone number for SMS alerts (change as needed)
    private static final String ALERT_PHONE_NUMBER = "1234567890";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dbHelper = new DatabaseHelper(getContext());

        // Set up ListView and adapter for displaying items
        itemsListView = binding.listView;
        itemsList = new ArrayList<>();
        adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_list_item_1, itemsList);
        itemsListView.setAdapter(adapter);

        // Load items from the database
        loadItemsFromDatabase();

        // Set up Floating Action Button to add a new item
        binding.getRoot().findViewById(R.id.fabAddItem).setOnClickListener(v -> showAddItemDialog());

        // Set up click listener for updating an item when tapped
        itemsListView.setOnItemClickListener((parent, view1, position, id) -> {
            // Expected format: "ID: 1 | ItemName (Quantity)"
            String itemInfo = itemsList.get(position);
            try {
                String[] parts = itemInfo.split("\\|");
                String idPart = parts[0].trim();  // "ID: 1"
                int itemId = Integer.parseInt(idPart.split(":")[1].trim());

                String nameAndQty = parts[1].trim();  // "ItemName (Quantity)"
                String name = nameAndQty.substring(0, nameAndQty.indexOf("(")).trim();
                String qtyStr = nameAndQty.substring(nameAndQty.indexOf("(") + 1, nameAndQty.indexOf(")")).trim();
                int quantity = Integer.parseInt(qtyStr);

                showUpdateItemDialog(itemId, name, quantity);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error parsing item details", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up long click listener for deleting an item
        itemsListView.setOnItemLongClickListener((parent, view1, position, id) -> {
            String itemInfo = itemsList.get(position);
            try {
                String[] parts = itemInfo.split("\\|");
                String idPart = parts[0].trim();  // "ID: 1"
                int itemId = Integer.parseInt(idPart.split(":")[1].trim());

                new AlertDialog.Builder(getContext())
                        .setTitle("Delete Item")
                        .setMessage("Are you sure you want to delete this item?")
                        .setPositiveButton("Delete", (dialog, which) -> {
                            boolean isDeleted = dbHelper.deleteItem(itemId);
                            if (isDeleted) {
                                Toast.makeText(getContext(), "Item deleted", Toast.LENGTH_SHORT).show();
                                loadItemsFromDatabase();
                            } else {
                                Toast.makeText(getContext(), "Deletion failed", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .create()
                        .show();
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error parsing item details", Toast.LENGTH_SHORT).show();
            }
            return true; // Indicates the long press was handled
        });
    }

    // Load items from the database and update the ListView
    private void loadItemsFromDatabase() {
        itemsList.clear();
        Cursor cursor = dbHelper.getAllItems();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QUANTITY));
                String itemInfo = "ID: " + id + " | " + name + " (" + quantity + ")";
                itemsList.add(itemInfo);
            } while (cursor.moveToNext());
            cursor.close();
        }
        adapter.notifyDataSetChanged();
    }

    // Show dialog to add a new item
    private void showAddItemDialog() {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

        EditText editTextName = dialogView.findViewById(R.id.editTextItemName);
        EditText editTextQuantity = dialogView.findViewById(R.id.editTextItemQuantity);

        new AlertDialog.Builder(getContext())
                .setTitle("Add New Item")
                .setView(dialogView)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = editTextName.getText().toString().trim();
                    String quantityStr = editTextQuantity.getText().toString().trim();
                    if (name.isEmpty() || quantityStr.isEmpty()) {
                        Toast.makeText(getContext(), "Both fields are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int quantity;
                    try {
                        quantity = Integer.parseInt(quantityStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    boolean isInserted = dbHelper.insertItem(name, quantity);
                    if (isInserted) {
                        Toast.makeText(getContext(), "Item added successfully", Toast.LENGTH_SHORT).show();
                        loadItemsFromDatabase();
                        // If the quantity is low, send an SMS alert.
                        if (quantity < LOW_INVENTORY_THRESHOLD) {
                            sendSMSAlert("Low inventory alert: " + name + " only " + quantity + " left.");
                        }
                    } else {
                        Toast.makeText(getContext(), "Failed to add item", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    // Show dialog to update an existing item
    private void showUpdateItemDialog(int itemId, String currentName, int currentQuantity) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);

        EditText editTextName = dialogView.findViewById(R.id.editTextItemName);
        EditText editTextQuantity = dialogView.findViewById(R.id.editTextItemQuantity);

        // Pre-fill fields with current values
        editTextName.setText(currentName);
        editTextQuantity.setText(String.valueOf(currentQuantity));

        new AlertDialog.Builder(getContext())
                .setTitle("Update Item")
                .setView(dialogView)
                .setPositiveButton("Update", (dialog, which) -> {
                    String updatedName = editTextName.getText().toString().trim();
                    String updatedQtyStr = editTextQuantity.getText().toString().trim();
                    if (updatedName.isEmpty() || updatedQtyStr.isEmpty()) {
                        Toast.makeText(getContext(), "Both fields are required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int updatedQuantity;
                    try {
                        updatedQuantity = Integer.parseInt(updatedQtyStr);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), "Quantity must be a number", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    boolean isUpdated = dbHelper.updateItem(itemId, updatedName, updatedQuantity);
                    if (isUpdated) {
                        Toast.makeText(getContext(), "Item updated", Toast.LENGTH_SHORT).show();
                        loadItemsFromDatabase();
                        // Send SMS alert if updated quantity is below threshold
                        if (updatedQuantity < LOW_INVENTORY_THRESHOLD) {
                            sendSMSAlert("Low inventory alert: " + updatedName + " only " + updatedQuantity + " left.");
                        }
                    } else {
                        Toast.makeText(getContext(), "Update failed", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    // Method to send an SMS alert with a given message
    private void sendSMSAlert(String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(ALERT_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(getContext(), "SMS Alert sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getContext(), "Failed to send SMS Alert", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
