package com.example.scanner10;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.Arrays;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData<ArrayList<String>> items = new MutableLiveData<>(new ArrayList<>(Arrays.asList("Paper Towels", "Plastic Bags", "Paper Bags", "Dryer Sheets", "Broom Handles")));
    private final MutableLiveData<ArrayList<String>> numbs = new MutableLiveData<>(new ArrayList<>(Arrays.asList("44", "67", "35", "101", "32")));

    public LiveData<ArrayList<String>> getItems() {
        return items;
    }

    public LiveData<ArrayList<String>> getNumbs() {
        return numbs;
    }

    public void setItems(ArrayList<String> newItems) {
        items.setValue(newItems);
    }

    public void setNumbs(ArrayList<String> newNumbs) {
        numbs.setValue(newNumbs);
    }

    public interface ListUpdater {
        void update(ArrayList<String> list);
    }
}
